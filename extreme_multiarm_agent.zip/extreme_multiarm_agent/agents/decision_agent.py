from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List
import numpy as np


@dataclass
class SubTask:
    name: str
    description: str
    priority: int
    target_type: str
    required_arms: int
    risk_sensitivity: float


@dataclass
class DecisionPlan:
    macro_task: str
    reasoning_summary: str
    subtasks: List[SubTask]


class DecisionAgent:
    """Long-chain task decomposition agent.

    In production you can replace _rule_based_plan() with an LLM call. The returned plan is kept
    structured so it can be sent to the scheduler and low-level controller API.
    """

    def __init__(self, high_risk_threshold: float, severe_risk_threshold: float):
        self.high_risk_threshold = high_risk_threshold
        self.severe_risk_threshold = severe_risk_threshold

    def make_plan(self, macro_task: str, risk_report, obs) -> DecisionPlan:
        risk = risk_report.global_risk
        if risk >= self.severe_risk_threshold:
            mode = "severe"
        elif risk >= self.high_risk_threshold:
            mode = "high"
        else:
            mode = "normal"

        subtasks: List[SubTask] = []
        if mode == "severe":
            subtasks.append(SubTask("scout_safe_corridor", "优先探索低风险通道，避免所有机械臂同时进入危险区域", 1, "corridor", 1, 0.95))
            subtasks.append(SubTask("stabilize_payload", "两台机械臂靠近载荷并保持稳定支撑", 2, "payload", 2, 0.90))
            subtasks.append(SubTask("deliver_to_target", "沿低风险路线协同搬运至目标区域", 3, "target", 3, 0.92))
        elif mode == "high":
            subtasks.append(SubTask("risk_aware_approach", "采用风险规避策略接近载荷", 1, "payload", 2, 0.75))
            subtasks.append(SubTask("transport_payload", "多机械臂协同运输载荷", 2, "target", 3, 0.78))
            subtasks.append(SubTask("guard_and_monitor", "一台机械臂保持外围监测与避障", 3, "guard", 1, 0.70))
        else:
            subtasks.append(SubTask("fast_approach", "快速接近载荷", 1, "payload", 2, 0.45))
            subtasks.append(SubTask("transport_payload", "协同运输载荷到目标点", 2, "target", 3, 0.50))
            subtasks.append(SubTask("assist_alignment", "辅助末端对齐和稳定", 3, "target", 1, 0.40))

        reasoning = (
            f"根据环境感知结果，系统处于{mode}风险模式；"
            f"主导风险为{risk_report.dominant_risk}。因此优先进行安全通道或风险规避，"
            f"再执行载荷稳定和协同搬运。"
        )
        return DecisionPlan(macro_task=macro_task, reasoning_summary=reasoning, subtasks=subtasks)
