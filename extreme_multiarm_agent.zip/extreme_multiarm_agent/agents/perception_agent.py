from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List
import numpy as np


@dataclass
class RiskReport:
    global_risk: float
    payload_risk: float
    target_risk: float
    arm_risks: Dict[int, float]
    dominant_risk: str
    textual_summary: str


class EnvironmentPerceptionAgent:
    """Extracts semantic risk and converts it into quantitative indicators."""

    def __init__(self, risk_weights: Dict[str, float]):
        self.risk_weights = risk_weights

    def analyze(self, obs, env) -> RiskReport:
        payload_risk_map = env.local_risk(obs["payload"])
        target_risk_map = env.local_risk(obs["target"])
        arm_risks = {
            a.arm_id: env.weighted_risk(a.pos, self.risk_weights)
            for a in obs["arms"]
        }
        all_risk_map = dict(payload_risk_map)
        for k, v in target_risk_map.items():
            all_risk_map[k] = max(all_risk_map.get(k, 0.0), v)
        dominant = max(all_risk_map, key=all_risk_map.get)
        payload_risk = sum(self.risk_weights.get(k, 0) * v for k, v in payload_risk_map.items())
        target_risk = sum(self.risk_weights.get(k, 0) * v for k, v in target_risk_map.items())
        global_risk = float(np.mean([payload_risk, target_risk] + list(arm_risks.values())))
        summary = (
            f"当前主导风险为{dominant}，全局风险={global_risk:.3f}，"
            f"载荷区域风险={payload_risk:.3f}，目标区域风险={target_risk:.3f}。"
        )
        return RiskReport(
            global_risk=float(global_risk),
            payload_risk=float(payload_risk),
            target_risk=float(target_risk),
            arm_risks=arm_risks,
            dominant_risk=dominant,
            textual_summary=summary,
        )
