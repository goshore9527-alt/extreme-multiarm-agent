from __future__ import annotations

from typing import Dict, List
import numpy as np


class SchedulerAgent:
    """Assigns subtasks to follower manipulators and produces controller-level commands."""

    def __init__(self, controller_cfg):
        self.cfg = controller_cfg

    def _risk_to_controller_params(self, risk_sensitivity: float):
        # Smaller alpha means more conservative CVaR tail optimization.
        alpha = self.cfg.cvar_alpha_max - risk_sensitivity * (self.cfg.cvar_alpha_max - self.cfg.cvar_alpha_min)
        smc_gain = self.cfg.smc_gain_min + risk_sensitivity * (self.cfg.smc_gain_max - self.cfg.smc_gain_min)
        boundary = self.cfg.boundary_layer_max - risk_sensitivity * (self.cfg.boundary_layer_max - self.cfg.boundary_layer_min)
        return float(alpha), float(smc_gain), float(boundary)

    def schedule(self, plan, risk_report, obs, env) -> Dict[int, Dict]:
        arms = sorted(obs["arms"], key=lambda a: risk_report.arm_risks.get(a.arm_id, 0.0))
        commands: Dict[int, Dict] = {}
        used = set()

        for subtask in sorted(plan.subtasks, key=lambda s: s.priority):
            candidates = [a for a in arms if a.arm_id not in used]
            selected = candidates[:subtask.required_arms]
            alpha, smc_gain, boundary = self._risk_to_controller_params(subtask.risk_sensitivity)
            waypoint = self._waypoint_for(subtask.target_type, obs, env)
            for arm in selected:
                used.add(arm.arm_id)
                commands[arm.arm_id] = {
                    "subtask": subtask.name,
                    "waypoint": waypoint,
                    "cvar_alpha": alpha,
                    "smc_gain": smc_gain,
                    "boundary_layer": boundary,
                    "risk_avoidance": 0.35 + 0.55 * subtask.risk_sensitivity,
                    "speed_scale": 0.75 + 0.35 * (1.0 - subtask.risk_sensitivity),
                }

        # Unused arms act as monitors or assistants.
        for arm in obs["arms"]:
            if arm.arm_id not in commands:
                alpha, smc_gain, boundary = self._risk_to_controller_params(0.55)
                commands[arm.arm_id] = {
                    "subtask": "monitor_and_assist",
                    "waypoint": (obs["payload"] + obs["target"]) / 2.0,
                    "cvar_alpha": alpha,
                    "smc_gain": smc_gain,
                    "boundary_layer": boundary,
                    "risk_avoidance": 0.60,
                    "speed_scale": 0.85,
                }
        return commands

    def _waypoint_for(self, target_type: str, obs, env):
        if target_type == "payload":
            return obs["payload"]
        if target_type == "target":
            return obs["target"]
        if target_type == "guard":
            return np.array([obs["payload"][0] + 1.0, obs["payload"][1] + 0.7])
        if target_type == "corridor":
            # A simple low-risk corridor waypoint, can be replaced by RRT/A*.
            return np.array([3.0, 2.2])
        return obs["payload"]
