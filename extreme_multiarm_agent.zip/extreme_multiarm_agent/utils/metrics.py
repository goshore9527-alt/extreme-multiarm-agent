from __future__ import annotations

from typing import Dict, List
import numpy as np


def compute_metrics(history: List[Dict], success: bool) -> Dict[str, float]:
    if not history:
        return {"success": float(success)}
    dist = np.array([h["distance_to_target"] for h in history], dtype=float)
    risk = np.array([h["global_risk"] for h in history], dtype=float)
    final_dist = float(dist[-1])
    mean_risk = float(np.mean(risk))
    tail_k = max(1, int(0.2 * len(risk)))
    cvar_risk = float(np.mean(np.sort(risk)[-tail_k:]))
    convergence_step = next((i for i, d in enumerate(dist) if d < 0.6), len(dist))
    return {
        "success": float(success),
        "final_distance": final_dist,
        "mean_global_risk": mean_risk,
        "cvar_top20_risk": cvar_risk,
        "convergence_step": float(convergence_step),
        "min_distance": float(np.min(dist)),
    }
