from __future__ import annotations

from pathlib import Path
from typing import List, Dict
import matplotlib.pyplot as plt
import numpy as np


def plot_history(history: List[Dict], out_dir: str):
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    if not history:
        return
    steps = np.array([h["step"] for h in history])
    dist = np.array([h["distance_to_target"] for h in history])
    risk = np.array([h["global_risk"] for h in history])

    plt.figure(figsize=(8, 4.8))
    plt.plot(steps, dist, label="payload-target distance")
    plt.xlabel("Step")
    plt.ylabel("Distance")
    plt.title("Task Convergence Curve")
    plt.legend()
    plt.tight_layout()
    plt.savefig(out / "distance_curve.png", dpi=180)
    plt.close()

    plt.figure(figsize=(8, 4.8))
    plt.plot(steps, risk, label="global risk")
    plt.xlabel("Step")
    plt.ylabel("Risk score")
    plt.title("Global Risk Curve")
    plt.legend()
    plt.tight_layout()
    plt.savefig(out / "risk_curve.png", dpi=180)
    plt.close()

    plt.figure(figsize=(6, 6))
    for arm_id in range(4):
        xs = [h[f"arm_{arm_id}_x"] for h in history]
        ys = [h[f"arm_{arm_id}_y"] for h in history]
        plt.plot(xs, ys, label=f"Arm {arm_id}")
    plt.plot([h["payload_x"] for h in history], [h["payload_y"] for h in history], label="Payload")
    plt.scatter([history[-1]["target_x"]], [history[-1]["target_y"]], marker="x", label="Target")
    plt.xlabel("x")
    plt.ylabel("y")
    plt.title("Multi-Arm Scheduling Trajectories")
    plt.legend()
    plt.tight_layout()
    plt.savefig(out / "trajectories.png", dpi=180)
    plt.close()
