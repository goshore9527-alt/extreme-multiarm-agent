from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple
import numpy as np


@dataclass
class RiskSource:
    name: str
    center: np.ndarray
    radius: float
    intensity: float


@dataclass
class ArmState:
    arm_id: int
    pos: np.ndarray
    vel: np.ndarray
    assigned_subtask: str = "idle"
    cvar_alpha: float = 0.20
    smc_gain: float = 4.0
    boundary_layer: float = 0.12
    finished: bool = False


class ExtremeMultiArmEnv:
    """A lightweight extreme-environment simulator for multi-manipulator scheduling.

    This is not a replacement for your real 3-DOF manipulator dynamics. It is a task-level
    environment used to verify the LLM/multi-agent scheduling layer. The low-level action
    can be replaced by your CVaR-TD3-SMC controller API.
    """

    def __init__(self, cfg):
        self.cfg = cfg
        self.rng = np.random.default_rng(cfg.seed)
        self.workspace = np.array(cfg.workspace_size, dtype=float)
        self.step_id = 0
        self.target = np.array([8.8, 8.6], dtype=float)
        self.payload = np.array([1.4, 1.3], dtype=float)
        self.risk_sources: List[RiskSource] = []
        self.arms: List[ArmState] = []
        self.history: List[Dict] = []
        self.reset()

    def reset(self):
        self.step_id = 0
        self.payload = np.array([1.4, 1.3], dtype=float)
        self.target = np.array([8.8, 8.6], dtype=float)
        self.risk_sources = [
            RiskSource("heat", np.array([4.8, 4.5], dtype=float), 2.0, 0.90),
            RiskSource("smoke", np.array([6.8, 6.1], dtype=float), 1.8, 0.82),
            RiskSource("collapse", np.array([3.2, 7.2], dtype=float), 1.45, 0.78),
            RiskSource("obstacle", np.array([6.0, 3.2], dtype=float), 1.15, 0.70),
        ]
        starts = [
            [0.9, 0.9], [1.2, 1.8], [1.9, 1.0], [2.2, 1.8]
        ]
        self.arms = [
            ArmState(i, np.array(starts[i], dtype=float), np.zeros(2, dtype=float))
            for i in range(self.cfg.n_arms)
        ]
        self.history = []
        return self.observe()

    def observe(self) -> Dict:
        return {
            "step": self.step_id,
            "payload": self.payload.copy(),
            "target": self.target.copy(),
            "arms": [a for a in self.arms],
            "risk_sources": self.risk_sources,
            "global_risk": self.global_risk_score(),
            "done": self.is_done(),
        }

    def local_risk(self, pos: np.ndarray) -> Dict[str, float]:
        risks = {}
        for src in self.risk_sources:
            d = np.linalg.norm(pos - src.center)
            val = src.intensity * np.exp(-(d ** 2) / (2.0 * src.radius ** 2))
            risks[src.name] = float(np.clip(val, 0.0, 1.0))
        return risks

    def weighted_risk(self, pos: np.ndarray, weights: Dict[str, float]) -> float:
        risks = self.local_risk(pos)
        return float(np.clip(sum(weights.get(k, 0.0) * v for k, v in risks.items()), 0.0, 1.0))

    def global_risk_score(self) -> float:
        points = [self.payload, self.target] + [a.pos for a in self.arms]
        vals = []
        for p in points:
            vals.append(max(self.local_risk(p).values()))
        return float(np.mean(vals))

    def _repulsive_risk_gradient(self, pos: np.ndarray) -> np.ndarray:
        grad = np.zeros(2, dtype=float)
        for src in self.risk_sources:
            diff = pos - src.center
            dist = np.linalg.norm(diff) + 1e-6
            if dist < src.radius * 2.5:
                grad += (diff / dist) * src.intensity * np.exp(-dist / src.radius)
        return grad

    def step(self, low_level_commands: Dict[int, Dict]) -> Dict:
        self.step_id += 1
        active_positions = []

        for arm in self.arms:
            cmd = low_level_commands.get(arm.arm_id, {})
            waypoint = np.array(cmd.get("waypoint", self.payload), dtype=float)
            speed_scale = float(cmd.get("speed_scale", 1.0))
            risk_avoidance = float(cmd.get("risk_avoidance", 0.4))
            arm.cvar_alpha = float(cmd.get("cvar_alpha", arm.cvar_alpha))
            arm.smc_gain = float(cmd.get("smc_gain", arm.smc_gain))
            arm.boundary_layer = float(cmd.get("boundary_layer", arm.boundary_layer))
            arm.assigned_subtask = str(cmd.get("subtask", arm.assigned_subtask))

            direction = waypoint - arm.pos
            dist = np.linalg.norm(direction) + 1e-8
            direction = direction / dist
            repulse = self._repulsive_risk_gradient(arm.pos)
            desired = direction + risk_avoidance * repulse
            desired = desired / (np.linalg.norm(desired) + 1e-8)
            noise = self.rng.normal(0.0, 0.012, size=2)

            risk_here = max(self.local_risk(arm.pos).values())
            risk_slowdown = 1.0 - 0.45 * risk_here
            step_vec = desired * self.cfg.base_speed * speed_scale * risk_slowdown + noise
            arm.vel = step_vec / self.cfg.dt
            arm.pos = np.clip(arm.pos + step_vec, [0, 0], self.workspace)
            active_positions.append(arm.pos.copy())

            if np.linalg.norm(arm.pos - waypoint) < 0.35:
                if "target" in arm.assigned_subtask or "deliver" in arm.assigned_subtask:
                    arm.finished = True

        # Payload is moved by the centroid of arms in transport mode.
        transporters = [a for a in self.arms if "transport" in a.assigned_subtask or "deliver" in a.assigned_subtask]
        if transporters:
            centroid = np.mean([a.pos for a in transporters], axis=0)
            to_centroid = centroid - self.payload
            to_target = self.target - self.payload
            move = 0.05 * to_centroid + 0.045 * to_target / (np.linalg.norm(to_target) + 1e-8)
            self.payload = np.clip(self.payload + move, [0, 0], self.workspace)

        obs = self.observe()
        self.history.append(self._snapshot(obs))
        return obs

    def _snapshot(self, obs: Dict) -> Dict:
        return {
            "step": obs["step"],
            "payload_x": float(self.payload[0]),
            "payload_y": float(self.payload[1]),
            "target_x": float(self.target[0]),
            "target_y": float(self.target[1]),
            "global_risk": float(obs["global_risk"]),
            "distance_to_target": float(np.linalg.norm(self.payload - self.target)),
            **{f"arm_{a.arm_id}_x": float(a.pos[0]) for a in self.arms},
            **{f"arm_{a.arm_id}_y": float(a.pos[1]) for a in self.arms},
            **{f"arm_{a.arm_id}_alpha": float(a.cvar_alpha) for a in self.arms},
            **{f"arm_{a.arm_id}_smc_gain": float(a.smc_gain) for a in self.arms},
        }

    def is_done(self) -> bool:
        return bool(np.linalg.norm(self.payload - self.target) < 0.45 or self.step_id >= self.cfg.max_steps)

    def success(self) -> bool:
        return bool(np.linalg.norm(self.payload - self.target) < 0.45)
