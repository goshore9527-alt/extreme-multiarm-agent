from __future__ import annotations

from typing import Dict
import numpy as np


class CVaRTD3SMCControlAPI:
    """Adapter layer between the scheduling Agent and low-level CVaR-TD3-SMC controller.

    Replace `compute_command()` internals with your trained PyTorch policy call, for example:
        state = build_state(...)
        rl_action = self.actor(state)
        torque = smc_layer(rl_action, cvar_alpha, smc_gain, boundary_layer)

    The current implementation returns task-level commands for the lightweight simulator.
    """

    def __init__(self, torque_limit=(80.0, 55.0, 30.0)):
        self.torque_limit = np.array(torque_limit, dtype=float)

    def compute_command(self, arm_state, scheduled_cmd: Dict) -> Dict:
        waypoint = np.array(scheduled_cmd["waypoint"], dtype=float)
        e = waypoint - arm_state.pos
        dist = np.linalg.norm(e) + 1e-8
        direction = e / dist

        # A proxy torque command for logging/interface demonstration.
        smc_gain = float(scheduled_cmd.get("smc_gain", 4.0))
        boundary = float(scheduled_cmd.get("boundary_layer", 0.1))
        pseudo_sliding = np.tanh(e / max(boundary, 1e-4))
        pseudo_tau = np.array([
            smc_gain * pseudo_sliding[0],
            smc_gain * pseudo_sliding[1],
            smc_gain * 0.5 * np.mean(pseudo_sliding),
        ])
        pseudo_tau = np.clip(pseudo_tau, -self.torque_limit, self.torque_limit)

        out = dict(scheduled_cmd)
        out["pseudo_tau"] = pseudo_tau
        out["distance_to_waypoint"] = float(dist)
        out["direction"] = direction
        return out
